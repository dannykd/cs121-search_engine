import { FC, Fragment } from "react";
import Link from "next/link";
import { Transition, Menu } from "@headlessui/react";
import { Bars3Icon } from "@heroicons/react/24/outline";
import NextLink from "./NextLink";

interface NavbarProps {}

const Navbar: FC<NavbarProps> = () => {
  return (
    <div className="w-full border-b p-4 pb-2">
      <div className="hidden justify-between md:flex">
        <Link href="/">
          <h1 className="text-2xl font-bold text-black">CS-121 Search Engine</h1>
        </Link>
      </div>

      <div className="flex w-full justify-between rounded-lg md:hidden">
        <Link href="/">
          <h1 className="text-2xl font-bold text-black">CS-121 Search Engine</h1>
        </Link>
      </div>
    </div>
  );
};

export default Navbar;
