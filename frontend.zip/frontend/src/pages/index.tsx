import type { NextPage } from "next";
import Head from "next/head";
import type { FormEvent } from "react";
import Image from "next/image";
import React, { useState } from 'react';


const Home: NextPage = () => {

  const [links, setLinks] = useState([]);

  const handleForm = async (event:FormEvent) => {
    event.preventDefault()
    const form = new FormData(event.target as HTMLFormElement);
    const query_object = Object.fromEntries(form);
    console.log(query_object)
    const response = await fetch(
      'http://localhost:5000/api/query',
      {
        method: "POST",
        headers: { "Content-Type": "application/json"},
        body: JSON.stringify(query_object),
      }
    );
    let body = await response.json();
    console.log(body);
    setLinks(body.links)

  }

  return (
    <div>
      <div className="mx-auto max-w-4xl flex justify-center">
        <div className="flex-col">
          <h1 className="mt-6 text-2xl"></h1>
          <form
            onSubmit={(event: FormEvent<HTMLFormElement>) => handleForm(event)}
          >
              <input
                  type="text"
                  name="query"
                  placeholder="enter search terms..."
                  className="rounded-lg p-1 text-black ring"
              >
              
              </input>
              <button type="submit" className="bg-blue-700 text-white rounded-lg p-2 ml-4">search</button>
          </form>

        </div>
      </div>
      <div className="flex justify-center">
        <div>
            {
            links.map((link) => {
              return <div>
                  <a href={link} className="text-sm">{link}</a>
                </div>
            })
          }

        </div>
      </div>
    </div>
  );
};

export default Home;
